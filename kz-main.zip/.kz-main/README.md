# .kz
kairat
